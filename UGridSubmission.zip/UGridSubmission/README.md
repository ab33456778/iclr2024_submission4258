# Learning An Efficient-And-Rigorous Neural Multigrid Solver

This repository is the official implementation of 
Learning An Efficient-And-Rigorous Neural Multigrid Solver. 

Please refer to `./UGrid/README.md` for more details. 
(`CPMG` is the Python C++/CUDA extension for testing.)
