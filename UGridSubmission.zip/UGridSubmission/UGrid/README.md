# Learning An Efficient-And-Rigorous Neural Multigrid Solver

This repository is the official implementation of 
Learning An Efficient-And-Rigorous Neural Multigrid Solver. 

## Requirements

To install requirements:

```bash
conda create --name <env> --file var/requirements.txt
conda activate <env>
pip install opencv-python loguru
```

## Data Generation

To generate the dataset, run this command:

```bash
bash ./script/generate.sh
```

Please modify `generate.sh` to generate the `train`, `evaluate` and `test` datasets of the desired size. 

## Training

To train the model(s) in the paper, run this command:

```bash
bash ./script/train.sh
```

## Evaluation

To re-produce the testing results (of UGrid), run this command: 

```bash
bash ./script/test.sh
```

To re-produce the testing results of AMGCL and NVIDIA AmgX, 
first compile the Python C++/CUDA extension 
(located in directory `../CPMG/`, please refer to the README there for how to compile), 
and copy the shared module `cpmg.cpythonxxxxx.so` to `./comparasion/cpmg/`.
Then, run the command 

```bash
python compare.py
```

To re-prosuce the testing results of Hsieh et al, 
Please refer to `./comparasion/Hsieh/REDME.md`. 

## Pre-trained Models

Self-contained in `./checkpoint/22`. 

## Notes

This program does not include the training and testing code for Hsieh et al.'s model. 
The modified version of Hsieh et al.'s program (for testing) is attached in `./comparasion/Hsieh/`. 
Please refer to the README.md in that directory on how to train and test Hsieh et al.'s model. 
(Minimal changes were made to Hsieh et al.'s program to train the model and to add testing code.) 
