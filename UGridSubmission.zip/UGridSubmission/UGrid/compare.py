import shutil
import typing

import cv2
import numpy as np
import torch

import comparasion.cpmg as cpmg
import util


# noinspection DuplicatedCode
def amgcl_solve_on_single_data(testcase, size):
    b, m, f = util.get_testcase(testcase, size, util.get_device())
    x = util.initial_guess(b, m, 'random')
    b_np = b.cpu().squeeze().numpy()
    m_np = m.cpu().squeeze().numpy()
    f_np = f.cpu().squeeze().numpy()
    x_np = x.cpu().squeeze().numpy()

    total_time_elapsed: float = 0.0
    total_error: float = 0.0
    duplicate: int = 20

    for _ in range(duplicate):
        iters, error, time_elapsed, y = cpmg.amgcl_solve(m_np, f_np, b_np, x_np, 1e-4)
        total_time_elapsed += time_elapsed
        total_error += error

    log_str = f'AMGCL CUDA {testcase}_{size} {total_time_elapsed / duplicate} ms, rel res {total_error / duplicate}'
    print(log_str)


# noinspection DuplicatedCode
def amgx_solve_on_single_data(testcase, size):
    b, m, f = util.get_testcase(testcase, size, util.get_device())
    x0 = util.initial_guess(b, m, 'random')

    b_np: np.ndarray = b.detach().cpu().squeeze().numpy()
    m_np: np.ndarray = m.detach().cpu().squeeze().numpy()
    f_np: np.ndarray = f.detach().cpu().squeeze().numpy()
    x0_np: np.ndarray = x0.detach().cpu().squeeze().numpy()

    duplicate: int = 20
    total_time_elapsed: float = 0.0
    total_error: float = 0.0

    for _ in range(duplicate):
        iters, time_elapsed, y = cpmg.amgx_solve(m_np, f_np, b_np, x0_np)
        total_time_elapsed += time_elapsed
        total_error += util.relative_residue(torch.from_numpy(y.reshape((1, 1, size, size))).cuda(), b, m, f)[1].item()

    log_str = f'AMGX {testcase}_{size} {total_time_elapsed / duplicate} ms, rel res {total_error / duplicate}'
    print(log_str)


def main() -> None:
    # Same seed as the UGrid model for fair comparasion
    seed: int = 9590589012167207234
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    testcase_lst: typing.List[str] = ['bag', 'cat', 'lock', 'note', 'poisson_region', 'punched_curve',
                                      'shape_l', 'shape_square', 'shape_square_poisson', 'star']

    # Test AMGCL CUDA
    for size in [1025, 257]:
        for testcase in testcase_lst:
            amgcl_solve_on_single_data(testcase, size)

    # Test NVIDIA AMGX
    cpmg.amgx_initialize()
    for size in [1025, 257]:
        for testcase in testcase_lst:
            amgx_solve_on_single_data(testcase, size)
    cpmg.amgx_finalize()


if __name__ == '__main__':
    main()
