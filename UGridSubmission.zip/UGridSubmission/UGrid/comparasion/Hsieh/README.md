# README

- Hsieh et al.'s program is available at: https://github.com/ermongroup/Neural-PDE-Solver
- We modified the following content to make the program run and to add testing code: 
    - `scripts/train.sh`, `scripts/test.sh`, `scripts/generate.sh`
    - `train.py`, `test.py`
    - `models/heat_model.py` 
        - To train the model and to add functionality to predict our testcases. 
          Hsieh et al. hard-coded all their testcases into the model as an `evaluate` function.
        - We have tried to train the model with Hsieh et al.'s original `train` method as-is, but the model diverged. 
          We are training their model with a modified version of the `train` method, 
          which lets the model run for 16 iterations during training 
          (the original implementation let the model run a random number of iterations during training.)
    - Other minor changes also apply (e.g., removing unused packages/utilities like visualization.)

## To Generate Data, Train the Model or to Test the Model: 

Run the cooresponding scripts `scripts/train.sh`, `scripts/test.sh`, `scripts/generate.sh` directly. 
Please modify the path if needed. 

## Pre-trained Model

Self-contained in `ckpts/heat/257x257/unet322_random_iter16_0_gt0_adam1e-02`

