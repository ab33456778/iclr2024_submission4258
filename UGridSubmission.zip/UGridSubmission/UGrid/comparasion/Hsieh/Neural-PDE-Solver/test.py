import glob
import math
import os
import shutil
import time
import typing

import cv2
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch

from models.heat_model import HeatModel
from data import get_data_loader
import utils


def draw_poisson_region(img: np.ndarray,
                        c: typing.Union[int, typing.Iterable, typing.Tuple[int]],
                        r: int,
                        f: float) -> None:
    """
    Generate a Poisson region for sharp boundary. [Hou'15]
    :param img: Target to draw this Poisson region.
    :param c: Center of this Poisson region.
    :param r: Radius of this Poisson region.
    :param f: Laplacian inside inner part of this region.
    :return: None
    """
    dr = int(np.ceil(0.05 * r))
    r1: int = r - dr
    f2: float = -1 * r1 * r1 / (r * r - r1 * r1) * f
    cv2.circle(img, c, r, f2, cv2.FILLED)
    cv2.circle(img, c, r1, f, cv2.FILLED)


def get_testcase(name: str, size: int, device: torch.device) \
        -> typing.Tuple[torch.Tensor, torch.Tensor, typing.Optional[torch.Tensor]]:
    testcase_path: str = os.path.join(f'var/testcase/{size}/{name}.bmp')
    assert os.path.exists(testcase_path)

    bc_mask: np.ndarray = cv2.imread(testcase_path, cv2.IMREAD_GRAYSCALE)
    bc_mask = (bc_mask == 0).astype(np.float32)

    if name == 'bag':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.9
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.0001
        f[:int(0.43 * size), :] = -0.01
        f *= (bc_mask == 0)
    elif name == 'cat':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.82
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.0001
        f *= 1 - bc_mask
    elif name == 'flower' or name == 'flower2':   # DONETODO turn into sharp feature
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.82
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.0001
        f *= 1 - bc_mask
    elif name == 'lock':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.9
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.0001
        f[:int(0.43 * size), :] = -0.001
        f *= (bc_mask == 0)
    elif name == 'note':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.82
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.0001
        f *= 1 - bc_mask
    elif name == 'poisson_region':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, (0, -1)] = 200
        bc_value[(0, -1), :] = 0
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        cv2.circle(f, (int(0.25 * size), int(0.75 * size)), size // 8, 0.01, cv2.FILLED)
        cv2.circle(f, (int(0.75 * size), int(0.25 * size)), size // 8, -0.01, cv2.FILLED)
        draw_poisson_region(f, (int(0.25 * size), int(0.25 * size)), size // 8, -0.05)
        draw_poisson_region(f, (int(0.75 * size), int(0.75 * size)), size // 8, 0.05)
        f *= 1 - bc_mask
    elif name == 'punched_curve':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:size // 2, :size // 2] = 90
        bc_value[:size // 2, size // 2:] = -10
        bc_value[size // 2:, :size // 2] = 30
        bc_value[size // 2:, size // 2:] = -60
        bc_value *= bc_mask

        # f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f: np.ndarray = np.random.random(bc_mask.shape) * 0.01
        # f[:, 0:size // 3] = 0.0001
        # f[:, size // 3 * 2:] = -0.0005
        f[size // 2:, :] *= -1
        f *= 1 - bc_mask
    elif name == 'shape_l':
        bc_value: np.ndarray = np.ones_like(bc_mask, dtype=np.float32)
        bc_value *= bc_mask

        f: np.ndarray = np.ones_like(bc_mask, dtype=np.float32) * -0.001
        f *= 1 - bc_mask
    elif name == 'shape_square':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, (0, -1)] = 0.9
        bc_value[(0, -1), :] = 0.1
        bc_value *= bc_mask

        # f: typing.Optional[np.ndarray] = None
        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
    elif name == 'shape_square_poisson':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, (0, -1)] = 0.9
        bc_value[(0, -1), :] = 0.1
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, 0:size // 3] = 0.0005
        f[:, size // 3 * 2:] = -0.0001
        f[size // 2:, :] *= -1
        f *= 1 - bc_mask
    elif name == 'star':
        bc_value: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        bc_value[:, :] = 0.94
        bc_value *= bc_mask

        f: np.ndarray = np.zeros_like(bc_mask, dtype=np.float32)
        f[:, :] = -0.006
        f *= 1 - bc_mask
    else:
        raise NotImplementedError

    bc_value: torch.Tensor = torch.from_numpy(bc_value).unsqueeze(0).unsqueeze(0).to(device)
    bc_mask: torch.Tensor = torch.from_numpy(bc_mask).unsqueeze(0).unsqueeze(0).to(device)

    if f is not None:
        f: torch.Tensor = torch.from_numpy(f).unsqueeze(0).float().to(device)

    return bc_value, bc_mask, f


def initial_guess(bc_value: torch.Tensor, bc_mask: torch.Tensor, initialization: str) -> torch.Tensor:
    """
    Assemble the initial guess of solution.
    """
    if initialization == 'random':
        routine = torch.rand_like   # U[0, 1)
    elif initialization == 'zero':
        routine = torch.zeros_like
    else:
        raise NotImplementedError

    return (1 - bc_mask) * routine(bc_value) + bc_value


def test_on_single_data(testcase: str,
                        size: int,
                        model,
                        device: torch.device,
                        benchmark_iteration: typing.Optional[int] = None) \
        -> None:
    with torch.no_grad():
        test_loss_dict: typing.Dict[str, typing.List[torch.Tensor]] = {}

        image_size: int = size
        bc_value, bc_mask, f = get_testcase(testcase, image_size, device)

        time_lst: typing.List[float] = []

        if benchmark_iteration is None:
            benchmark_iteration = 1

        bc_hsieh = torch.stack([bc_value.squeeze(), bc_mask.squeeze()], 0).unsqueeze(0)
        f_hsieh = f / 4

        # rhs = bc_hsieh[:, 0] * bc_hsieh[:, 1] + f_hsieh * (1 - bc_hsieh[:, 1])
        # norm = utils.norm(rhs)
        # print('rhs_norm = ', norm, 'abs_tol = ', 1e-4 * norm)

        x0 = initial_guess(bc_value, bc_mask, 'random')

        # # DONETODO: Heish benchmark
        # np.save(f'var/conv/tmp/x0.npy',
        #         x0.detach().squeeze().cpu().numpy())

        for _ in range(benchmark_iteration):
            start_time: float = time.perf_counter_ns()
            x = x0.squeeze(0).to(device)
            y_hsieh = model.predict(x, bc_hsieh, f_hsieh, rel_tol=1e-4)
            time_lst.append(time.perf_counter_ns() - start_time)

        print(f'[Test] Hsieh et al. used {np.mean(time_lst) / 1e6} ms')

        y = y_hsieh.unsqueeze(0)
        tup: typing.Tuple[torch.Tensor, torch.Tensor] = utils.relative_residue(y, bc_value, bc_mask, f)
        abs_residual_norm, rel_residual_norm = tup
        abs_residual_norm: torch.Tensor = abs_residual_norm.mean()
        rel_residual_norm: torch.Tensor = rel_residual_norm.mean()

        # print('abs_norm / rhs_norm = ', abs_residual_norm / norm)

        if 'abs_residual_norm' in test_loss_dict:
            test_loss_dict['abs_residual_norm'].append(abs_residual_norm)
        else:
            test_loss_dict['abs_residual_norm']: typing.List[torch.Tensor] = [abs_residual_norm]

        if 'rel_residual_norm' in test_loss_dict:
            test_loss_dict['rel_residual_norm'].append(rel_residual_norm)
        else:
            test_loss_dict['rel_residual_norm']: typing.List[torch.Tensor] = [rel_residual_norm]

        for k, v in test_loss_dict.items():
            print('[Test] {} = {} * 1e-5'.format(k, torch.mean(torch.tensor(v)) * 1e5))


def compare(testcase: str, size: int, model, device: torch.device) -> None:
    print(f'[Test] Testing Hsieh et al. on {testcase} of size {size}')
    # DONETODO: Heish Benchmark
    test_on_single_data(testcase, size, model, device, benchmark_iteration=100)


def main():
    torch.manual_seed(9590589012167207234)
    torch.cuda.manual_seed_all(9590589012167207234)

    opt, logger, stats = utils.build(is_train=False)

    # Load model opt
    model_opt = np.load(os.path.join(opt.ckpt_path, 'opt.npy'), allow_pickle=True).item()

    # Change geometry to the testing one
    model_opt.is_train = False
    model_opt.geometry = opt.geometry
    model_opt.n_evaluation_steps = opt.n_evaluation_steps

    model = HeatModel(model_opt)
    # logger.print('Loading data from {}'.format(opt.dset_path))
    # data_loader = get_data_loader(opt)
    # logger.print('####### Data Loaded ########')

    for epoch in opt.which_epochs:
        if epoch < 0:
            # Pick last epoch
            checkpoints = glob.glob(os.path.join(opt.ckpt_path, 'net_*.pth'))
            assert len(checkpoints) > 0
            epochs = [int(path[:-4].split('_')[-1]) for path in checkpoints]
            epoch = sorted(epochs)[-1]

        model.load(opt.ckpt_path, epoch)
        logger.print('Checkpoint loaded from {}, epoch {}'.format(opt.ckpt_path, epoch))

    testcase_lst: typing.List[str] = ['bag', 'cat', 'lock', 'note', 'poisson_region', 'punched_curve',
                                      'shape_l', 'shape_square', 'shape_square_poisson', 'star']

    for size in [1025, 257]:
        for testcase in testcase_lst:
            os.mkdir('var/conv/tmp/')
            compare(testcase=testcase, size=size, model=model, device=torch.device('cuda'))
            shutil.move('var/conv/tmp/', f'var/conv/{testcase}_{size}/')


    # x = utils.initialize(x, bc, opt.initialization)
    # y = model.predict(x, bc, f)
    # abs_residual_error, rel_residual_error = utils.relative_residue(
    #         y.unsqueeze(0),
    #         bc[:, 0].unsqueeze(0),
    #         bc[:, 1].unsqueeze(0),
    #         f.unsqueeze(0) if f is not None else None)
    # print(f'abs_residual_error = {abs_residual_error}\n'
    #       f'rel_residual_error = {rel_residual_error}')


if __name__ == '__main__':
    matplotlib.use('QtAgg')
    main()
