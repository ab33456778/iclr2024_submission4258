import copy
import numpy as np
import os

import torch
import torch.random

from data import get_data_loader
import utils
from models.heat_model import HeatModel
# from test import evaluate


def main():
    opt, logger, stats = utils.build(is_train=True)
    np.save(os.path.join(opt.ckpt_path, 'opt.npy'), opt)
    data_loader = get_data_loader(opt)
    logger.print('Loading training data from {}'.format(opt.dset_path))
    logger.print('####### Training Data loaded #########')

    # Validation
    val_opt = copy.deepcopy(opt)
    val_opt.is_train = False
    val_opt.batch_size = 1
    val_opt.data_limit = 20
    val_loader = get_data_loader(val_opt)
    logger.print('Loading validation data from {}'.format(opt.dset_path))
    logger.print('####### Validation Data loaded #########\n')

    model = HeatModel(opt)

    if not os.path.exists(opt.ckpt_path):
        os.mkdir(opt.ckpt_path)

    for epoch in range(opt.start_epoch, opt.n_epochs):
        # Train
        model.setup(is_train=True)
        train_epoch_loss_dict = {}

        for step, data in enumerate(data_loader):
            bc, x, gt = data['bc'], data['x'], data['final']
            f = None if 'f' not in data else data['f']

            x = utils.initialize(x, bc, opt.initialization)
            loss_dict = model.train(x, bc, f, gt)

            for k, v in loss_dict['loss'].items():
                if k in train_epoch_loss_dict:
                    train_epoch_loss_dict[k].append(v)
                else:
                    train_epoch_loss_dict[k] = [v]

        for k, v in train_epoch_loss_dict.items():
            logger.print('[Epoch {}/{}] {} = {}'.format(epoch, opt.n_epochs - 1, k, torch.mean(torch.tensor(v))))

        # Evaluate
        if opt.evaluate_every > 0 and (epoch + 1) % opt.evaluate_every == 0:
            eval_loss_dict = {}
            model.setup(is_train=False)

            for step, data in enumerate(val_loader):
                bc, x = data['bc'], data['x']
                f = None if 'f' not in data else data['f']

                x = utils.initialize(x, bc, opt.initialization)
                loss_dict = model.evaluate(x, bc, f)

                for k, v in loss_dict['loss'].items():
                    if k in eval_loss_dict:
                        eval_loss_dict[k].append(v)
                    else:
                        eval_loss_dict[k] = [v]

            for k, v in eval_loss_dict.items():
                logger.print('[Evaluation] {} = {}'.format(k, torch.mean(torch.tensor(v))))

        # Scheduler step
        logger.print('[Epoch {}/{}] Current learning rate = {}'.format(epoch,
                                                                       opt.n_epochs - 1,
                                                                       model.optimizer.param_groups[0]['lr']))
        model.scheduler.step()

        # Save checkpoint
        if (epoch + 1) % opt.save_every == 0 or epoch == opt.n_epochs - 1:
            logger.print('[Epoch {}/{}] Model saved.\n'.format(epoch, opt.n_epochs - 1))
            model.save(opt.ckpt_path, epoch + 1)
        else:
            logger.print('')


if __name__ == '__main__':
    main()