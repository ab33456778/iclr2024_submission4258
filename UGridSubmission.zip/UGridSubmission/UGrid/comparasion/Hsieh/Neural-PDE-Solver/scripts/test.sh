#!/bin/bash
CUDA_VISIBLE_DEVICES=0 \
python test.py \
  --n_evaluation_steps 64 \
  --initialization random \
  --which_epochs 300 \
  --load_ckpt_path './ckpts/heat/257x257/unet322_random_iter16_0_gt0_adam1e-02' \
  --dset_dir '../../Downloads/Hsieh' \
  --geometry 'cylinders' \
  --image_size 257
