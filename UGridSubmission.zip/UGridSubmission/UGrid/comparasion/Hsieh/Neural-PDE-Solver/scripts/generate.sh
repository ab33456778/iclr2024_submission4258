#!/bin/bash
CUDA_VISIBLE_DEVICES=0 \
python generation.py \
  --save_dir '../../Downloads/Hsieh' \
  --image_size 257 \
  --save_every 1 \
  --geometry square \
  --poisson 0 \
  --n_runs 1000
