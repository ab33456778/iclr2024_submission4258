#!/bin/bash
CUDA_VISIBLE_DEVICES=0 \
python train.py \
  --batch_size 1 \
  --evaluate_every 1 \
  --save_every 1 \
  --n_epochs 10000 \
  --lr_init 1e-2 \
  --max_iter_steps 16 \
  --max_iter_steps_from_gt 0 \
  --n_evaluation_steps 400 \
  --image_size 257 \
  --iterator unet \
  --conv_n_layers 6 \
  --mg_n_layers 3 \
  --mg_pre_smoothing 2 \
  --mg_post_smoothing 2 \
  --initialization random \
  --geometry 'cylinders' \
  --ckpt_dir './ckpts' \
  --ckpt_name '' \
  --dset_dir '../../Downloads/Hsieh' \
  --dset_name 'heat' \

