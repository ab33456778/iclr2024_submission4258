import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler

from .base_model import BaseModel
from .get_iterator import get_iterator
import utils


class HeatModel(BaseModel):
    def __init__(self, opt):
        super(HeatModel, self).__init__()

        # Iterator
        self.iterator, self.compare_model, self.operations_ratio, self.is_train = get_iterator(opt)
        self.nets['iterator'] = self.iterator

        if self.is_train:
            self.criterion_mse = nn.MSELoss().cuda()
            if opt.optimizer == 'sgd':
                self.optimizer = optim.SGD(self.iterator.parameters(), lr=opt.lr_init)
            elif opt.optimizer == 'adam':
                self.optimizer = optim.Adam(self.iterator.parameters(), lr=opt.lr_init)
            else:
                raise NotImplementedError

            self.scheduler = lr_scheduler.StepLR(self.optimizer, 100, 0.1)

            # Hyperparameters
            self.max_iter_steps = opt.max_iter_steps
            self.max_iter_steps_from_gt = opt.max_iter_steps_from_gt
            self.lambdas = {'gt': opt.lambda_gt}
        else:
            self.max_iter_steps = opt.n_evaluation_steps

    # DOES NOT CONVERGE AT ALL WHEN USING HSIEH'S VERSION AS FOLLOWS AS-IS
    # def train(self, x, gt, bc, f):
    # '''
    # x, gt: size (batch_size x image_size x image_size)
    # '''
    # if not self.is_train:
    #   return {}
    #
    # x = x.cuda()
    # gt = gt.cuda()
    # bc = bc.cuda()
    # if f is not None:
    #   f = f.cuda()
    # loss_dict = {}
    #
    # if self.lambdas['gt'] < 1:
    #   N = np.random.randint(1, self.max_iter_steps + 1)
    #   # N-1 iterations from x
    #   y = x.detach()
    #   for i in range(N - 1):
    #     y = self.iter_step(y, bc, f).detach()
    #   # One more iteration (no detach)
    #   y = self.iter_step(y, bc, f)
    #   loss_x = self.criterion_mse(y, gt)
    #   loss_dict['loss_x'] = loss_x.item()
    # else:
    #   loss_x = 0
    #
    # if self.lambdas['gt'] > 0:
    #   M = np.random.randint(1, self.max_iter_steps_from_gt + 1)
    #   y_gt = gt.detach()
    #   for i in range(M - 1):
    #     y_gt = self.iter_step(y_gt, bc, f).detach()
    #   # One more iteration
    #   y_gt = self.iter_step(y_gt, bc, f)
    #   loss_gt = self.criterion_mse(y_gt, gt)
    #   loss_dict['loss_gt'] = loss_gt.item()
    # else:
    #   loss_gt = 0
    #
    # loss = (1 - self.lambdas['gt']) * loss_x + self.lambdas['gt'] * loss_gt
    # self.optimizer.zero_grad()
    # loss.backward()
    # self.optimizer.step()
    #
    # return {'loss': loss_dict}

    # noinspection DuplicatedCode
    def train(self, x, bc, f, gt):
        """
        x, gt: size (batch_size x image_size x image_size)
        """
        x = x.cuda()
        bc = bc.cuda()

        if f is not None:
            f = f.cuda()

        gt = gt.cuda()

        loss_dict = {}

        y = x

        for _ in range(self.max_iter_steps):
            y = self.iter_step(y, bc, f)

        # loss
        loss_x = self.criterion_mse(y, gt)
        loss_dict['loss_x_mean'] = torch.mean(loss_x).item()

        # with torch.no_grad():
        #     loss_x_max = torch.mean(utils.fd_error(y, bc, f))
        #     loss_dict['loss_x_max'] = loss_x_max.item()

        loss = loss_x

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {'loss': loss_dict}

    # noinspection PyPep8Naming, DuplicatedCode
    def predict(self, x, bc, f, rel_tol=None):
        with torch.no_grad():
            x = x.cuda()
            bc = bc.cuda()

            if f is not None:
                f = f.cuda()

            if rel_tol is not None:
                rhs = bc[:, 0] * bc[:, 1]
                if f is not None:
                    rhs = rhs + f * (1 - bc[:, 1])
                abs_tol = utils.norm(rhs) * rel_tol

            # print('In predict: rhs_norm = ', utils.norm(rhs), 'abs_tol = ', abs_tol)

            y = x

            for i in range(1, self.max_iter_steps + 1):
                y = self.iter_step(y, bc, f)

                # # DONETODO: Hsieh benchmark
                # np.save(f'var/conv/tmp/x{i}.npy',
                #         y.detach().squeeze().cpu().numpy())

                if rel_tol is not None and \
                        i % 4 == 0 and \
                        utils.absolute_residue(y.unsqueeze(0), bc[:, 1], f * 4, reduction='norm') <= abs_tol:
                    break

            return y

    # noinspection PyPep8Naming, DuplicatedCode
    def evaluate(self, x, bc, f):
        """
        x: size (batch_size x image_size x image_size)
        """
        with torch.no_grad():
            loss_dict = {}

            y = self.predict(x, bc, f)

            # loss
            abs_residual_error, rel_residual_error = utils.relative_residue(
                    torch.unsqueeze(y, 1),
                    torch.unsqueeze(bc[:, 0], 1).cuda(),
                    torch.unsqueeze(bc[:, 1], 1).cuda(),
                    f)

            loss_dict['abs_residual_error'] = abs_residual_error.item()
            loss_dict['rel_residual_error'] = rel_residual_error.item()

        return {'loss': loss_dict}

    def iter_step(self, x, bc, f):
        ''' Perform one iteration step. '''
        return self.iterator.iter_step(x, bc, f)

    def H(self, x, bc, f):
        ''' Perform one iteration of H. '''
        return self.iterator.H(x.unsqueeze(1), bc).squeeze(1)

    def get_activation(self):
        return self.iterator.act

    def change_activation(self, act):
        ''' Change activation function, used to calculate eigenvalues '''
        self.iterator.act = act

    # def evaluate(self, x, gt, bc, f, n_steps):
    #     '''
    #     x, f, gt: size (batch_size x image_size x image_size)
    #     Run Jacobi and our iterator for n_steps iterations, and calculate errors.
    #     Return a dictionary of errors: size (batch_size x (n_steps + 1)).
    #     '''
    #     bc = bc.cuda()
    #     x = x.cuda()
    #     gt = gt.cuda()
    #     if f is not None:
    #         f = f.cuda()
    #
    #     if utils.is_bc_mask(x, bc):
    #         print('Initializing with zero')
    #         x = utils.initialize(x, bc, 'zero')
    #     # Calculate starting error
    #     starting_error = utils.l2_error(x, gt).cpu()
    #     results = {}
    #
    #     if self.iterator.name().startswith('UNet'):
    #         # Unet, set threshold to be higher
    #         threshold = 0.01
    #     else:
    #         threshold = 0.002
    #
    #     if self.compare_model is not None:
    #         # Jacobi
    #         fd_errors, _ = utils.calculate_errors(x, bc, f, gt, self.compare_model.iter_step,
    #                                               n_steps, starting_error, threshold)
    #         results['Jacobi errors'] = fd_errors
    #
    #     # error of model
    #     errors, x = utils.calculate_errors(x, bc, f, gt, self.iter_step,
    #                                        n_steps, starting_error, threshold)
    #     results['model errors'] = errors
    #
    #     return results, x
