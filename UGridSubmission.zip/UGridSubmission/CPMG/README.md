# Python C++/CUDA Extension for Comparasion

This is a Python C++/CUDA extension for AMGCL and NVIDIA AmgX. 
The extension is powered by pybind11. 

## Dependencies

- Basic Python and C++ Toolchains
- CUDA Toolkit 11.8
- [AMGCL](https://github.com/ddemidov/amgcl)
- [NVIDIA AmgX](https://developer.nvidia.com/amgx)
- [pybind11](https://github.com/pybind/pybind11)
- [LibTorch](https://pytorch.org/get-started/locally/)
  - Get pre-cxx11 ABI [here](https://download.pytorch.org/libtorch/cu118/libtorch-shared-with-deps-2.0.1%2Bcu118.zip)
- The following dependencies could be obtains from `apt`:
  - Boost: `$ sudo apt install libboost-dev`
  - TBB: `$ sudo apt install libtbb-dev`

Please refer to `./CMakeLists.txt` for more details. 
Please also update the variables in this script, 
e.g., path hints for `find_package` commands, CUDA architecture, etc. 

## How to Compile

```bash
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j32
```
